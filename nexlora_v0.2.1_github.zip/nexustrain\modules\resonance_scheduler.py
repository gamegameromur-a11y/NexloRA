"""
NexusTrain — ResonanceScheduler™
Author: Ömür Bera Işık
"""
from __future__ import annotations
import collections, logging, math
from typing import List
import torch
from torch.optim import Optimizer
from ..errors import NexusError
from .spectra_optimizer import _fft_spectrum

log = logging.getLogger("NexusTrain")

def _clamp(v,lo,hi): return max(lo,min(hi,v))
def _to_float(x): return x.detach().float().mean().item()

class TrainingPhase:
    WARMUP      = "warmup"
    STABLE      = "stable"
    CONVERGENCE = "convergence"
    PLATEAU     = "plateau"
    UNSTABLE    = "unstable"

class ResonanceScheduler:
    """
    ResonanceScheduler™ — Gradient Spektrumu Tabanlı Öz-Ayarlı LR

    Eğitim fazını (warmup/stable/convergence/plateau/unstable) otomatik
    tespit ederek LR'yi akıllıca ayarlar.
    """
    def __init__(self, optimizer: Optimizer, cfg):
        self.optimizer  = optimizer
        self.cfg        = cfg
        self.base_lr    = cfg.base_lr
        self.min_lr     = cfg.min_lr
        self._step      = 0
        self._phase     = TrainingPhase.WARMUP
        self._loss_hist : List[float] = []
        self._gnorm_hist: List[float] = []
        self._phase_hist: List[str]   = []
        self._last_lr   = cfg.base_lr
        self._plateau_count = 0
        log.info(f"ResonanceSched: 🎼  base_lr={cfg.base_lr:.2e}, "
                 f"sensitivity={cfg.resonance_sensitivity}")

    def step(self, loss: float, grad_norm: float):
        self._step += 1
        self._loss_hist.append(loss)
        self._gnorm_hist.append(grad_norm)
        if len(self._loss_hist)  > 256: self._loss_hist.pop(0)
        if len(self._gnorm_hist) > 256: self._gnorm_hist.pop(0)
        new_lr = self._compute_lr()
        self._set_lr(new_lr)
        self._last_lr = new_lr
        self._phase_hist.append(self._phase)

    def _compute_lr(self) -> float:
        step = self._step; cfg = self.cfg; sens = cfg.resonance_sensitivity
        if step <= cfg.warmup_steps:
            self._phase = TrainingPhase.WARMUP
            return self.base_lr * (step / max(cfg.warmup_steps, 1))
        if len(self._gnorm_hist) >= 4:
            if self._gnorm_hist[-1] > sum(self._gnorm_hist[-8:])/8 * (3.0 - sens):
                self._phase = TrainingPhase.UNSTABLE
                return max(self._last_lr * 0.5, self.min_lr)
        if len(self._loss_hist) >= 16:
            recent = self._loss_hist[-8:]
            delta  = max(recent) - min(recent)
            avg    = sum(recent) / 8 + 1e-12
            if delta / avg < 0.001:
                self._plateau_count += 1
                if self._plateau_count > 5:
                    self._phase = TrainingPhase.PLATEAU
                    return min(self._last_lr * (1.0 + 0.05 * sens), self.base_lr)
            else:
                self._plateau_count = 0
        if len(self._gnorm_hist) >= 16:
            spectrum = _fft_spectrum(self._gnorm_hist[-32:])
            if spectrum:
                total_power = sum(spectrum) + 1e-12
                entropy     = -sum((s/total_power)*math.log(s/total_power+1e-12) for s in spectrum)
                norm_entropy= entropy / (math.log(len(spectrum)+1e-12) + 1e-12)
                if norm_entropy < 0.3:
                    self._phase = TrainingPhase.CONVERGENCE
                    progress = (step - cfg.warmup_steps) / max(1, step)
                    cosine   = 0.5 * (1 + math.cos(math.pi * progress))
                    return max(self.min_lr + (self.base_lr - self.min_lr) * cosine, self.min_lr)
                self._phase = TrainingPhase.STABLE
        return self._last_lr * (1.0 - 1e-4)

    def _set_lr(self, lr: float):
        lr = _clamp(lr, self.min_lr, self.base_lr)
        for pg in self.optimizer.param_groups: pg["lr"] = lr

    @property
    def current_lr(self) -> float: return self._last_lr
    @property
    def current_phase(self) -> str: return self._phase

    def report(self):
        pc = collections.Counter(self._phase_hist)
        log.info(f"ResonanceSched: 🎼  Fazlar={dict(pc)}, son LR={self._last_lr:.2e}")



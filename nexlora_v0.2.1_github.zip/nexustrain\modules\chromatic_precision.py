"""
NexusTrain — ChromaticPrecision™
Katman-Bazlı Dinamik Hassasiyet Motoru
Author: Ömür Bera Işık
"""
from __future__ import annotations
import logging, math
from typing import Dict, List
import torch
import torch.nn as nn
from ..errors import NexusError

log = logging.getLogger("NexusTrain")
_HAS_BF16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()

def _clamp(v,lo,hi): return max(lo,min(hi,v))
def _to_float(x): return x.detach().float().mean().item()

class LayerSensitivity:
    __slots__ = ("name","score","dtype","grad_var","update_count")
    def __init__(self, name):
        self.name=name; self.score=0.5; self.dtype=None
        self.grad_var=[]; self.update_count=0

class ChromaticPrecision:
    """
    ChromaticPrecision™ — Her katmana gradient varyansına göre ayrı dtype atar.
    FP32 / BF16 / FP16 karışık hassasiyet — standart mixed precision'dan üstün.
    """
    def __init__(self, cfg, model: nn.Module):
        self.cfg   = cfg
        self._sens: Dict[str, LayerSensitivity] = {}
        self._step = 0
        self._hooks= []
        self._analyzed = False
        self._setup_hooks(model)
        log.info(f"ChromaticPrec: 🌈  analiz_adımı={cfg.precision_analysis_steps}")

    def _setup_hooks(self, model: nn.Module):
        for name, module in model.named_modules():
            for pname, param in module.named_parameters(recurse=False):
                full = f"{name}.{pname}" if name else pname
                self._sens[full] = LayerSensitivity(full)
                def make_hook(fname):
                    def _hook(grad):
                        with NexusError.guard("CHROMA_HOOK", f"Gradient hook: {fname}"):
                            if fname in self._sens and grad is not None:
                                s = self._sens[fname]
                                s.grad_var.append(_to_float(grad.float().var()))
                                if len(s.grad_var) > 32: s.grad_var.pop(0)
                                s.update_count += 1
                        return grad
                    return _hook
                h = param.register_hook(make_hook(full))
                self._hooks.append(h)

    def analyze_and_assign(self, model: nn.Module) -> Dict[str, str]:
        dtype_assignments: Dict[str, str] = {}
        for name, module in model.named_modules():
            for pname, param in module.named_parameters(recurse=False):
                full  = f"{name}.{pname}" if name else pname
                s     = self._sens.get(full)
                force = any(kw in full for kw in self.cfg.force_fp32_layers)
                if force:
                    target = "fp32"
                elif s is None or not s.grad_var:
                    target = "bf16"
                else:
                    avg_var = sum(s.grad_var) / len(s.grad_var)
                    score   = _clamp(math.log1p(avg_var) / 10.0, 0.0, 1.0)
                    s.score = score
                    if score > 0.7:   target = "fp32"
                    elif score > 0.3: target = "bf16" if _HAS_BF16 else "fp32"
                    else:             target = "fp16"
                dtype_assignments[full] = target
        self._analyzed = True
        fp32 = sum(1 for v in dtype_assignments.values() if v=="fp32")
        bf16 = sum(1 for v in dtype_assignments.values() if v=="bf16")
        fp16 = sum(1 for v in dtype_assignments.values() if v=="fp16")
        log.info(f"ChromaticPrec: 🌈  FP32={fp32}, BF16={bf16}, FP16={fp16}")
        return dtype_assignments

    def step(self): self._step += 1

    def remove_hooks(self):
        for h in self._hooks:
            try: h.remove()
            except: pass
        self._hooks.clear()

    def report(self):
        if not self._analyzed:
            log.info("ChromaticPrec: 🌈  Analiz henüz tamamlanmadı")
            return
        high = [n for n,s in self._sens.items() if s.score > 0.7]
        log.info(f"ChromaticPrec: 🌈  {len(high)} hassas parametre FP32'de korunuyor")



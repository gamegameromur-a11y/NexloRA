"""
NexLoRA - Merged Package
=======================

Combines FastLoRA v4.0 and NexusTrain v1.0 into a single package.

Usage:
    import nexlora

    # FastLoRA usage
    from nexlora import fastlora
    model, tokenizer = fastlora.FastLoRA("model-name").load()

    # NexusTrain usage
    from nexlora import nexustrain as nexus
    nt = nexus.NexusTrain(model, tokenizer, nexus.NexusConfig())

Author: Combined from FastLoRA and NexusTrain
License: MIT
Version: 0.2.1
"""

from . import fastlora
from . import nexustrain

__all__ = [
    "fastlora",
    "nexustrain",
]

__version__ = "0.2.1"
__author__ = "Combined from FastLoRA and NexusTrain"
__license__ = "MIT"

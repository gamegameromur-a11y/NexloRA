# NexLoRA

Merged package combining **FastLoRA v4.0** and **NexusTrain v1.0** into a single installable package.

**Authors:**
- FastLoRA: FastLoRA Contributors
- NexusTrain: Ömür Bera Işık

## Installation

```bash
pip install nexlora
```

## Usage

### FastLoRA Usage

```python
from nexlora import fastlora

model, tokenizer = fastlora.FastLoRA("meta-llama/Llama-3.2-3B").load()
# ... training ...
```

### NexusTrain Usage

```python
from nexlora import nexustrain

nt = nexustrain.NexusTrain(model, tokenizer, nexustrain.NexusConfig())
trainer = nt.patch_trainer(trainer)
nt.engage()
# ... training ...
```

### Environment Check

```bash
nexlora-check
```

## Features

### FastLoRA (v4.0)
- LoRA / QLoRA fine-tuning
- 2-bit quantization (independent of bitsandbytes)
- OOM recovery with auto-resume
- Custom Triton kernels (RMSNorm, SwiGLU, RoPE)
- Mixture of Experts (MoE) support
- Optuna hyperparameter tuning
- CPU/NVMe offloading (ZeRO-Infinity style)
- Smart VRAM guard

### NexusTrain (v1.0)
- CrystalCore™ - Runtime kernel crystallization
- MorphicMemory™ - Adaptive memory morphism
- SpectraOptimizer™ - Frequency domain optimizer
- ResonanceScheduler™ - Self-tuning learning rate
- ChromaticPrecision™ - Layer-wise dynamic precision
- GradientHarmonics™ - Wavelet-based gradient processing
- NeuralProfiler™ - LSTM-based training predictor
- CrystalPipeline™ - Self-reconfiguring training pipeline
- ZeroWaste™ - Unnecessary computation elimination

## License

MIT License - See LICENSE file for details.

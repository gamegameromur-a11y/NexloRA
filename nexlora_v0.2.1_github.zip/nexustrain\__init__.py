# NexLoRA Training Module

from nexlora.nexustrain.config import NexusConfig as TrainConfig
from nexlora.nexustrain.core import NexusTrain as Trainer
from nexlora.nexustrain.modules.crystal_core import CrystalCore
from nexlora.nexustrain.modules.morphic_memory import MorphicMemory
from nexlora.nexustrain.modules.spectra_optimizer import SpectraOptimizer
from nexlora.nexustrain.modules.resonance_scheduler import ResonanceScheduler, TrainingPhase
from nexlora.nexustrain.modules.chromatic_precision import ChromaticPrecision
from nexlora.nexustrain.modules.gradient_harmonics import GradientHarmonics
from nexlora.nexustrain.modules.neural_profiler import NeuralProfiler
from nexlora.nexustrain.modules.crystal_pipeline import CrystalPipeline
from nexlora.nexustrain.modules.zero_waste import ZeroWaste
from nexlora.nexustrain.modules.universal_adapter import UniversalAdapter
from nexlora.nexustrain.utils import nexus_wrap as train_wrap, nexus_check as train_check

__version__ = "1.0.0"
__author__ = "NexLoRA Team"
__license__ = "MIT"

__all__ = [
    "Trainer",
    "TrainConfig",
    "CrystalCore",
    "MorphicMemory",
    "SpectraOptimizer",
    "ResonanceScheduler",
    "TrainingPhase",
    "ChromaticPrecision",
    "GradientHarmonics",
    "NeuralProfiler",
    "CrystalPipeline",
    "ZeroWaste",
    "UniversalAdapter",
    "train_wrap",
    "train_check",
]

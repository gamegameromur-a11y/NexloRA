"""
NexusTrain — Hata Yönetimi
Author: Ömür Bera Işık
"""
from __future__ import annotations

import json
import logging
import threading
import time
import traceback
from typing import Dict, List, Optional

log = logging.getLogger("NexusTrain")


class NexusError:
    """
    Hiçbir hata sistemi çöktürmez.
    Her hata: KOD + NE + NEDEN + ÇÖZÜM + PERFORMANS ETKİSİ formatında raporlanır.
    """
    _registry: List[Dict] = []
    _lock = threading.Lock()

    @classmethod
    def report(cls, code: str, what: str, why: str, fix: str,
               impact: str = "minimal", exc: Exception = None, fatal: bool = False):
        with cls._lock:
            entry = dict(
                time=time.strftime("%H:%M:%S"),
                code=code, what=what, why=why, fix=fix,
                impact=impact,
                detail=str(exc) if exc else None,
                tb=traceback.format_exc() if exc else None,
            )
            cls._registry.append(entry)

        sym = {"minimal": "🟡", "moderate": "🟠", "severe": "🔴", "none": "🟢"}.get(impact, "⚪")
        border = "═" * 62
        log.error(f"\n{border}")
        log.error(f"  ❌  [{code}]")
        log.error(f"  📋  Ne oldu     : {what}")
        log.error(f"  🔍  Neden       : {why}")
        log.error(f"  🔧  Çözüm       : {fix}")
        log.error(f"  {sym}  Performans  : {impact}")
        if exc:
            log.error(f"  💬  Detay       : {exc}")
        log.error(border)
        if fatal:
            raise RuntimeError(f"[NexusTrain] Fatal: {what}")

    @classmethod
    def guard(cls, code: str, what: str, impact: str = "minimal"):
        """Context manager: hata olursa yutup loglar, sistemi durdurmaz."""
        class _G:
            def __enter__(self_): return self_
            def __exit__(self_, t, v, tb):
                if v is not None:
                    cls.report(code, what, str(v),
                               "Otomatik geri dönüş aktif", impact, exc=v)
                    return True
        return _G()

    @classmethod
    def summary(cls):
        n = len(cls._registry)
        if n == 0:
            log.info("NexusError   : ✅  Sıfır hata — mükemmel çalışma")
            return
        log.info(f"NexusError   : {n} hata oluştu:")
        for i, e in enumerate(cls._registry, 1):
            log.info(f"  {i:2d}. [{e['time']}] {e['code']}: {e['what']}")

    @classmethod
    def save(cls, path: str = "./nexustrain_errors.json"):
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(cls._registry, f, ensure_ascii=False, indent=2)
            if cls._registry:
                log.info(f"Hata Raporu  : → {path}")
        except Exception:
            pass

    @classmethod
    def clear(cls):
        with cls._lock:
            cls._registry.clear()


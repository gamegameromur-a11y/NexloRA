"""
NexusTrain — NeuralProfiler™
LSTM-Tabanlı Çevrimiçi Eğitim Tahminleyicisi
Author: Ömür Bera Işık
"""
from __future__ import annotations
import gc, logging, math
from typing import Dict, List
import torch
import torch.nn as nn
from ..errors import NexusError

log = logging.getLogger("NexusTrain")
def _clamp(v,lo,hi): return max(lo,min(hi,v))

class TinyLSTM(nn.Module):
    def __init__(self, input_size=4, hidden=16, out=3):
        super().__init__()
        self.lstm   = nn.LSTM(input_size, hidden, batch_first=True)
        self.out_fc = nn.Linear(hidden, out)
        self._hidden= None
    def forward(self, x):
        out, self._hidden = self.lstm(x, self._hidden)
        return self.out_fc(out[:, -1])
    def reset(self): self._hidden = None

class NeuralProfiler:
    """
    NeuralProfiler™ — LSTM ile bir sonraki adımda OOM ve gradient
    patlaması riskini tahmin eder, önleyici aksiyon alır.
    """
    def __init__(self, cfg):
        self.cfg    = cfg
        self.lstm   = TinyLSTM().eval()
        self._buffer: List[List[float]] = []
        self._step  = 0; self._alerts = 0
        log.info(f"NeuralProfiler: 🧠  pencere={cfg.profiler_window}, "
                 f"uyarı={cfg.profiler_alert_ms}ms")

    def observe(self, step_ms: float, loss: float, grad_norm: float, vram_pct: float):
        self._buffer.append([step_ms, loss, grad_norm, vram_pct])
        if len(self._buffer) > self.cfg.profiler_window: self._buffer.pop(0)
        self._step += 1
        if len(self._buffer) >= 8:
            self._react(self._predict(), step_ms, grad_norm, vram_pct)

    def _predict(self) -> Dict:
        try:
            with torch.no_grad():
                x = torch.tensor(self._buffer, dtype=torch.float32).unsqueeze(0)
                x = (x - x.mean(1, keepdim=True)) / (x.std(1, keepdim=True) + 1e-6)
                out = torch.sigmoid(self.lstm(x)).squeeze().tolist()
                if not isinstance(out, list): out = [out, 0.0, 0.0]
            return {k: _clamp(v,0,1) for k,v in zip(
                ["speed_risk","oom_risk","explode_risk"], out)}
        except Exception:
            return {"speed_risk":0.0,"oom_risk":0.0,"explode_risk":0.0}

    def _react(self, pred, step_ms, gnorm, vram_pct):
        if step_ms > self.cfg.profiler_alert_ms:
            log.warning(f"NeuralProfiler: ⚠️  Yavaş adım: {step_ms:.0f}ms")
            self._alerts += 1
        if pred["oom_risk"] > 0.75:
            gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
            log.warning(f"NeuralProfiler: 🧠  OOM riski {pred['oom_risk']:.0%} → önleyici GC")
            self._alerts += 1
        if pred["explode_risk"] > 0.75 and gnorm > 1.0:
            log.warning(f"NeuralProfiler: 🧠  Gradient patlaması riski {pred['explode_risk']:.0%}")
            self._alerts += 1

    def report(self):
        avg = sum(b[0] for b in self._buffer) / max(len(self._buffer), 1)
        log.info(f"NeuralProfiler: 🧠  {self._step} adım, ort.{avg:.0f}ms, {self._alerts} uyarı")



"""
NexusTrain — Ana Motor
Author: Ömür Bera Işık
"""
from __future__ import annotations

import gc
import json
import logging
import math
import os
import random
import time
import warnings
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from .config import NexusConfig
from .errors import NexusError
from .modules.crystal_core       import CrystalCore
from .modules.morphic_memory     import MorphicMemory
from .modules.spectra_optimizer  import SpectraOptimizer
from .modules.resonance_scheduler import ResonanceScheduler
from .modules.chromatic_precision import ChromaticPrecision
from .modules.gradient_harmonics  import GradientHarmonics
from .modules.neural_profiler     import NeuralProfiler
from .modules.crystal_pipeline    import CrystalPipeline
from .modules.zero_waste_adapter  import ZeroWaste, UniversalAdapter

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s \033[36m[NexusTrain]\033[0m %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("NexusTrain")

_HAS_COMPILE = tuple(int(x) for x in torch.__version__.split(".")[:2]) >= (2, 0)


def _mem_gb(device=None) -> Tuple[float, float]:
    if not torch.cuda.is_available(): return 0.0, 0.0
    d = device or torch.device("cuda")
    return (torch.cuda.memory_allocated(d) / 1e9,
            torch.cuda.get_device_properties(d).total_memory / 1e9)


class NexusTrain:
    """
    ╔══════════════════════════════════════════════════════════╗
    ║   NexusTrain v1.0 — Self-Crystallizing Training Engine   ║
    ║   Author: Ömür Bera Işık  |  License: MIT               ║
    ╚══════════════════════════════════════════════════════════╝

    Kullanım:
        from nexustrain import NexusTrain, NexusConfig

        cfg     = NexusConfig(power=1.0)
        nt      = NexusTrain(model, tokenizer, cfg)
        trainer = nt.patch_trainer(trainer)
        nt.engage()
        trainer.train()
        nt.summary()
    """

    VERSION = "1.0.0"
    AUTHOR  = "Ömür Bera Işık"

    def __init__(self, model: nn.Module,
                 tokenizer=None,
                 cfg: Optional[NexusConfig] = None):
        self.model     = model
        self.tokenizer = tokenizer
        self.cfg       = cfg or NexusConfig()

        torch.manual_seed(self.cfg.seed)
        random.seed(self.cfg.seed)

        self._device   = torch.device(self.cfg.device)
        self._step     = 0
        self._engaged  = False
        self._step_times: List[float] = []
        self._t_step_start = 0.0

        # Modüller
        self.crystal_core     : Optional[CrystalCore]        = None
        self.morphic_memory   : Optional[MorphicMemory]      = None
        self.spectra_opt      : Optional[SpectraOptimizer]   = None
        self.resonance_sched  : Optional[ResonanceScheduler] = None
        self.chromatic_prec   : Optional[ChromaticPrecision] = None
        self.grad_harmonics   : Optional[GradientHarmonics]  = None
        self.neural_profiler  : Optional[NeuralProfiler]     = None
        self.crystal_pipeline : Optional[CrystalPipeline]    = None
        self.zero_waste       : Optional[ZeroWaste]          = None
        self.universal_adapter: Optional[UniversalAdapter]   = None
        self._harmonic_hooks  : List                         = []

        self._print_banner()
        self._init_modules()

    # ── Banner ────────────────────────────────────────────────────────────────

    def _print_banner(self):
        print("\n" + "═"*60)
        print(f"  ⚡  NexusTrain v{self.VERSION}")
        print(f"  👤  {self.AUTHOR}")
        print(self.cfg.summary())
        print(f"\n  device={self.cfg.device} | dtype={self.cfg.dtype}")
        print("═"*60 + "\n")

    # ── Modül başlatma ────────────────────────────────────────────────────────

    def _init_modules(self):
        cfg = self.cfg

        if cfg.crystal_core and cfg.power > 0:
            with NexusError.guard("CRYSTAL_INIT", "CrystalCore başlatılamadı"):
                self.crystal_core = CrystalCore(cfg)
                self.crystal_core.inject_model(self.model)

        if cfg.morphic_memory and cfg.power > 0:
            with NexusError.guard("MORPH_INIT", "MorphicMemory başlatılamadı"):
                self.morphic_memory = MorphicMemory(cfg, self._device)

        if cfg.spectra_optimizer and cfg.power > 0:
            with NexusError.guard("SPECTRA_INIT", "SpectraOptimizer başlatılamadı"):
                self.spectra_opt = SpectraOptimizer(
                    self.model.parameters(),
                    lr               = cfg.base_lr,
                    betas            = (cfg.spectra_beta1, cfg.spectra_beta2),
                    eps              = cfg.spectra_eps,
                    weight_decay     = cfg.spectra_weight_decay,
                    spectral_damping = cfg.spectral_damping,
                    history_len      = cfg.spectra_history,
                    power            = cfg.power,
                )

        if cfg.resonance_scheduler and cfg.power > 0 and self.spectra_opt:
            with NexusError.guard("RESONANCE_INIT", "ResonanceScheduler başlatılamadı"):
                self.resonance_sched = ResonanceScheduler(self.spectra_opt, cfg)

        if cfg.chromatic_precision and cfg.power > 0:
            with NexusError.guard("CHROMA_INIT", "ChromaticPrecision başlatılamadı"):
                self.chromatic_prec = ChromaticPrecision(cfg, self.model)

        if cfg.gradient_harmonics and cfg.power > 0:
            with NexusError.guard("HARMONIC_INIT", "GradientHarmonics başlatılamadı"):
                self.grad_harmonics = GradientHarmonics(cfg)
                self._harmonic_hooks = self.grad_harmonics.register_hooks(self.model)

        if cfg.neural_profiler and cfg.power > 0:
            with NexusError.guard("PROFILER_INIT", "NeuralProfiler başlatılamadı"):
                self.neural_profiler = NeuralProfiler(cfg)

        if cfg.crystal_pipeline and cfg.power > 0:
            with NexusError.guard("PIPELINE_INIT", "CrystalPipeline başlatılamadı"):
                self.crystal_pipeline = CrystalPipeline(cfg)

        if cfg.zero_waste and cfg.power > 0:
            with NexusError.guard("WASTE_INIT", "ZeroWaste başlatılamadı"):
                self.zero_waste = ZeroWaste(cfg)
                self.zero_waste.analyze_model(self.model)

        if cfg.auto_detect_framework:
            with NexusError.guard("ADAPTER_INIT", "UniversalAdapter başlatılamadı"):
                self.universal_adapter = UniversalAdapter(cfg)

        log.info("NexusTrain   : ✅  Tüm modüller başlatıldı")

    # ── Engage ────────────────────────────────────────────────────────────────

    def engage(self) -> "NexusTrain":
        """Tüm sistemi aktive et — eğitimden önce çağrılmalı."""
        self._engaged = True

        if _HAS_COMPILE and self.cfg.power > 0.5 and not self.cfg.crystal_core:
            try:
                self.model = torch.compile(
                    self.model, mode=self.cfg.compile_mode, fullgraph=False)
                log.info(f"NexusTrain   : ✅  torch.compile aktif")
            except Exception as e:
                NexusError.report("COMPILE_FAIL", "torch.compile başarısız",
                                  str(e), "Compile olmadan devam", exc=e)

        log.info("NexusTrain   : ⚡  ENGAGE — motor aktive edildi")
        return self

    def patch_trainer(self, trainer) -> Any:
        """Herhangi bir trainer'ı NexusTrain ile bağla."""
        if self.universal_adapter:
            return self.universal_adapter.patch_trainer(trainer, self)
        log.warning("NexusTrain   : UniversalAdapter devre dışı")
        return trainer

    # ── Event handler'lar ─────────────────────────────────────────────────────

    def _on_step_begin(self, step: int):
        self._step         = step
        self._t_step_start = time.perf_counter()
        if self.crystal_core:     self.crystal_core.step()
        if self.morphic_memory:   self.morphic_memory.step()
        if self.grad_harmonics:   self.grad_harmonics.step()
        if self.crystal_pipeline: self.crystal_pipeline.step()
        if self.zero_waste:       self.zero_waste.step_analysis(self.model)
        if (self.chromatic_prec and step == self.cfg.precision_analysis_steps):
            self.chromatic_prec.analyze_and_assign(self.model)

    def _on_step_end(self, step: int, loss: float):
        step_ms = (time.perf_counter() - self._t_step_start) * 1000
        self._step_times.append(step_ms)
        if len(self._step_times) > 256: self._step_times.pop(0)

        grad_norm = self._compute_grad_norm()
        if self.resonance_sched:
            self.resonance_sched.step(loss, grad_norm)

        if self.neural_profiler:
            used, total = _mem_gb(self._device)
            self.neural_profiler.observe(step_ms, loss, grad_norm,
                                         used / (total + 1e-6))
        if self.crystal_pipeline:
            used, total = _mem_gb(self._device)
            self.crystal_pipeline.adapt_grad_accum(used / (total + 1e-6), 0.7)

        self._write_telemetry(step, step_ms, loss, grad_norm)

    def _on_log(self, logs: Dict, step: int):
        if not self.cfg.verbose: return
        phase = self.resonance_sched.current_phase if self.resonance_sched else "?"
        lr    = f"{self.resonance_sched.current_lr:.2e}" if self.resonance_sched else "?"
        loss  = logs.get("loss", "?")
        avg   = sum(self._step_times[-8:]) / max(len(self._step_times[-8:]), 1)
        log.info(f"Step {step:6d} │ loss={loss} │ lr={lr} │ faz={phase} │ {avg:.0f}ms/adım")

    def _compute_grad_norm(self) -> float:
        try:
            total = sum(p.grad.float().norm().item()**2
                        for p in self.model.parameters() if p.grad is not None)
            return math.sqrt(total)
        except Exception: return 0.0

    def _write_telemetry(self, step, ms, loss, gnorm):
        try:
            entry = dict(step=step, ms=round(ms,1), loss=round(loss,5),
                         gnorm=round(gnorm,4),
                         phase=self.resonance_sched.current_phase if self.resonance_sched else "?",
                         lr=self.resonance_sched.current_lr if self.resonance_sched else 0.0,
                         ts=time.strftime("%H:%M:%S"))
            with open(self.cfg.telemetry_file, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception: pass

    # ── Yardımcı metodlar ─────────────────────────────────────────────────────

    def async_checkpoint(self, path: Optional[str] = None):
        """Async checkpoint — eğitimi durdurmaz."""
        if self.crystal_pipeline:
            p = path or os.path.join(self.cfg.checkpoint_dir,
                                     f"nexus_step_{self._step}.pt")
            self.crystal_pipeline.queue_checkpoint(self.model, p, self._step)
        else:
            p = path or os.path.join(self.cfg.checkpoint_dir,
                                     f"nexus_step_{self._step}.pt")
            os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
            torch.save(self.model.state_dict(), p)
            log.info(f"NexusTrain   : 💾  Checkpoint → {p}")

    def get_optimizer(self) -> Optional[SpectraOptimizer]:
        return self.spectra_opt

    def get_scheduler(self) -> Optional[ResonanceScheduler]:
        return self.resonance_sched

    def summary(self):
        print("\n" + "═"*60)
        print(f"  📊  NexusTrain v{self.VERSION} — Eğitim Özeti")
        print(f"  👤  {self.AUTHOR}")
        print("═"*60)
        avg_ms = sum(self._step_times) / max(len(self._step_times), 1)
        print(f"  Toplam adım  : {self._step}")
        print(f"  Ort. hız     : {avg_ms:.0f} ms/adım")
        if torch.cuda.is_available():
            used, total = _mem_gb()
            print(f"  Son VRAM     : {used:.1f}/{total:.1f} GB")
        print()
        if self.crystal_core:     self.crystal_core.report()
        if self.morphic_memory:   self.morphic_memory.report()
        if self.resonance_sched:  self.resonance_sched.report()
        if self.chromatic_prec:   self.chromatic_prec.report()
        if self.grad_harmonics:   self.grad_harmonics.report()
        if self.neural_profiler:  self.neural_profiler.report()
        if self.crystal_pipeline: self.crystal_pipeline.report()
        if self.zero_waste:       self.zero_waste.report()
        NexusError.summary()
        NexusError.save()
        print("═"*60 + "\n")

    def cleanup(self):
        for h in self._harmonic_hooks:
            try: h.remove()
            except: pass
        if self.chromatic_prec:
            self.chromatic_prec.remove_hooks()
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        log.info("NexusTrain   : 🧹  Kaynaklar temizlendi")

    def __repr__(self):
        return (f"NexusTrain(v{self.VERSION}, author='{self.AUTHOR}', "
                f"power={self.cfg.power:.0%}, device={self.cfg.device}, "
                f"step={self._step})")


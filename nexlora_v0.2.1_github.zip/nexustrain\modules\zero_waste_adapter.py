"""
NexusTrain — ZeroWaste™ + UniversalAdapter™
Author: Ömür Bera Işık
"""
from __future__ import annotations
import logging, time
from functools import wraps
from typing import Any, Dict, List, Set
import torch
import torch.nn as nn
from ..errors import NexusError

log = logging.getLogger("NexusTrain")


# ── ZeroWaste™ ────────────────────────────────────────────────────────────────

class OperationWatcher:
    __slots__ = ("name","total_ms","calls")
    def __init__(self, name):
        self.name=name; self.total_ms=0.0; self.calls=0

class ZeroWaste:
    """
    ZeroWaste™ — Gereksiz hesap eliminasyonu.
    Sıfır gradient alan parametreleri tespit eder, atık operasyonları raporlar.
    """
    def __init__(self, cfg):
        self.cfg       = cfg
        self._watchers: Dict[str, OperationWatcher] = {}
        self._frozen:   Set[str]                    = set()
        self._step     = 0
        self._savings  = dict(frozen=0, cached=0)
        log.info(f"ZeroWaste    : ♻️   periyot={cfg.waste_detect_steps} adım")

    def analyze_model(self, model: nn.Module):
        frozen = 0
        for name, param in model.named_parameters():
            if not param.requires_grad:
                self._frozen.add(name); frozen += 1
        if frozen:
            log.info(f"ZeroWaste    : ♻️   {frozen} parametre zaten dondurulmuş")

    def watch(self, name: str, fn) -> Any:
        if name not in self._watchers:
            self._watchers[name] = OperationWatcher(name)
        w = self._watchers[name]
        @wraps(fn)
        def _wrapper(*a, **kw):
            t0 = time.perf_counter()
            r  = fn(*a, **kw)
            w.total_ms += (time.perf_counter()-t0)*1000
            w.calls    += 1
            return r
        return _wrapper

    def step_analysis(self, model: nn.Module):
        if self._step % self.cfg.waste_detect_steps == 0 and self._step > 50:
            zero_grad = [n for n,p in model.named_parameters()
                         if p.requires_grad and p.grad is None]
            if zero_grad and len(zero_grad) < 20:
                log.debug(f"ZeroWaste    : {len(zero_grad)} gradient almayan parametre")
        self._step += 1

    def report(self):
        log.info(f"ZeroWaste    : ♻️   {len(self._watchers)} operasyon izlendi, "
                 f"{len(self._frozen)} dondurulmuş parametre")


# ── UniversalAdapter™ ─────────────────────────────────────────────────────────

def _try_import(name):
    try: return __import__(name)
    except ImportError: return None

_transformers = _try_import("transformers")
_peft         = _try_import("peft")
_accelerate   = _try_import("accelerate")
_deepspeed    = _try_import("deepspeed")
_flash_attn   = _try_import("flash_attn")
_HAS_BF16     = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
_HAS_SDPA     = hasattr(torch.nn.functional, "scaled_dot_product_attention")


class FrameworkDetector:
    @staticmethod
    def detect() -> Dict[str, Any]:
        info = {}
        if _transformers: info["transformers"] = _transformers.__version__
        if _peft:         info["peft"]         = _peft.__version__
        if _accelerate:   info["accelerate"]   = _accelerate.__version__
        if _deepspeed:    info["deepspeed"]     = _deepspeed.__version__
        if _flash_attn:   info["flash_attn"]    = True
        if torch.cuda.is_available():
            info["cuda"]     = torch.version.cuda
            info["gpu_count"]= torch.cuda.device_count()
            info["gpu_name"] = torch.cuda.get_device_name(0)
            info["vram_gb"]  = torch.cuda.get_device_properties(0).total_memory / 1e9
        return info


class UniversalAdapter:
    """
    UniversalAdapter™ — HuggingFace, TRL, PEFT, DeepSpeed, Accelerate,
    ve vanilla PyTorch ile sorunsuz çalışır.
    """
    def __init__(self, cfg):
        self.cfg = cfg
        self.env = FrameworkDetector.detect()
        self._log_env()

    def _log_env(self):
        log.info("UniversalAdapt: 🌐  Framework tespiti:")
        for k, v in self.env.items():
            log.info(f"  • {k:<20} = {v}")

    def patch_trainer(self, trainer, nexus_engine) -> Any:
        if trainer is None: return trainer
        try:
            cls_name = type(trainer).__name__
            log.info(f"UniversalAdapt: 🌐  Trainer: {cls_name}")
            if _transformers and isinstance(trainer,
                    getattr(_transformers, "Trainer", type(None))):
                return self._patch_hf_trainer(trainer, nexus_engine)
            try:
                import trl
                if isinstance(trainer, trl.SFTTrainer):
                    return self._patch_hf_trainer(trainer, nexus_engine)
            except Exception: pass
            return self._patch_generic(trainer, nexus_engine)
        except Exception as e:
            NexusError.report("ADAPTER_FAIL", "Trainer patch başarısız",
                              str(e), "Manuel entegrasyon gerekebilir", exc=e)
            return trainer

    def _patch_hf_trainer(self, trainer, nt):
        try:
            from transformers import TrainerCallback
            class NexusCallback(TrainerCallback):
                def on_step_begin(self_, args, state, control, **kw):
                    nt._on_step_begin(state.global_step)
                def on_step_end(self_, args, state, control, **kw):
                    loss = state.log_history[-1].get("loss", 0.0) if state.log_history else 0.0
                    nt._on_step_end(state.global_step, loss)
                def on_log(self_, args, state, control, logs=None, **kw):
                    if logs: nt._on_log(logs, state.global_step)
                def on_train_end(self_, args, state, control, **kw):
                    nt.summary()
            trainer.add_callback(NexusCallback())
            log.info("UniversalAdapt: 🌐  ✅  HuggingFace Trainer patch'lendi")
            if nt.cfg.spectra_optimizer and nt.spectra_opt:
                try:
                    trainer.optimizer = nt.spectra_opt
                    log.info("UniversalAdapt: 🌐  ✅  SpectraOptimizer bağlandı")
                except Exception as e:
                    NexusError.report("OPT_BIND","Optimizer binding başarısız",
                                      str(e),"Mevcut optimizer korunuyor",exc=e)
        except Exception as e:
            NexusError.report("HF_PATCH","HF Trainer patch hatası",
                              str(e),"Temel callback olmadan devam",exc=e)
        return trainer

    def _patch_generic(self, trainer, nt):
        original = getattr(trainer, "training_step", None)
        if original is None: return trainer
        @wraps(original)
        def nexus_step(*args, **kwargs):
            nt._on_step_begin(getattr(trainer, "_step", 0))
            result = original(*args, **kwargs)
            loss   = result.item() if isinstance(result, torch.Tensor) else float(result)
            nt._on_step_end(getattr(trainer, "_step", 0), loss)
            return result
        trainer.training_step = nexus_step
        log.info("UniversalAdapt: 🌐  ✅  Generic trainer patch'lendi")
        return trainer

    def optimal_dtype(self) -> torch.dtype:
        if "gpu_name" in self.env:
            gpu = self.env["gpu_name"].lower()
            if any(x in gpu for x in ["a100","h100","a6000","3090","4090","4080"]):
                return torch.bfloat16
        return torch.bfloat16 if _HAS_BF16 else torch.float16

    def optimal_attention(self) -> str:
        if _flash_attn: return "flash_attention_2"
        if _HAS_SDPA:   return "sdpa"
        return "eager"



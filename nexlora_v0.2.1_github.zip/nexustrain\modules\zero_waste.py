"""
NexusTrain — ZeroWaste™ + UniversalAdapter™
Author: Ömür Bera Işık
"""
from __future__ import annotations
import logging, time
from functools import wraps
from typing import Any, Dict, List, Set
import torch
import torch.nn as nn
from ..errors import NexusError

log = logging.getLogger("NexusTrain")


# ── ZeroWaste™ ────────────────────────────────────────────────────────────────

class OperationWatcher:
    __slots__ = ("name","total_ms","calls")
    def __init__(self, name):
        self.name=name; self.total_ms=0.0; self.calls=0

class ZeroWaste:
    """
    ZeroWaste™ — Gereksiz hesap eliminasyonu.
    Sıfır gradient alan parametreleri tespit eder, atık operasyonları raporlar.
    """
    def __init__(self, cfg):
        self.cfg       = cfg
        self._watchers: Dict[str, OperationWatcher] = {}
        self._frozen:   Set[str]                    = set()
        self._step     = 0
        self._savings  = dict(frozen=0, cached=0)
        log.info(f"ZeroWaste    : ♻️   periyot={cfg.waste_detect_steps} adım")

    def analyze_model(self, model: nn.Module):
        frozen = 0
        for name, param in model.named_parameters():
            if not param.requires_grad:
                self._frozen.add(name); frozen += 1
        if frozen:
            log.info(f"ZeroWaste    : ♻️   {frozen} parametre zaten dondurulmuş")

    def watch(self, name: str, fn) -> Any:
        if name not in self._watchers:
            self._watchers[name] = OperationWatcher(name)
        w = self._watchers[name]
        @wraps(fn)
        def _wrapper(*a, **kw):
            t0 = time.perf_counter()
            r  = fn(*a, **kw)
            w.total_ms += (time.perf_counter()-t0)*1000
            w.calls    += 1
            return r
        return _wrapper

    def step_analysis(self, model: nn.Module):
        if self._step % self.cfg.waste_detect_steps == 0 and self._step > 50:
            zero_grad = [n for n,p in model.named_parameters()
                         if p.requires_grad and p.grad is None]



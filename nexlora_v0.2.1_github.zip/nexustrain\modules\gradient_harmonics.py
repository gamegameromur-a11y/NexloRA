"""
NexusTrain — GradientHarmonics™
Wavelet Tabanlı Gradient İşleme ve Sıkıştırma
Author: Ömür Bera Işık
"""
from __future__ import annotations
import logging, math
from typing import List
import torch
import torch.nn as nn
import torch.nn.functional as F
from ..errors import NexusError

log = logging.getLogger("NexusTrain")

def _clamp(v,lo,hi): return max(lo,min(hi,v))


def _wavelet_decompose(grad: torch.Tensor, levels: int = 3) -> List[torch.Tensor]:
    """Haar wavelet ayrıştırması — sıfır bağımlılık."""
    result = []
    x = grad.float().flatten()
    for _ in range(levels):
        if x.numel() < 2: break
        n = (x.numel() // 2) * 2; x = x[:n]
        evens = x[0::2]; odds = x[1::2]
        result.append((evens - odds) * 0.7071)
        x = (evens + odds) * 0.7071
    result.append(x)
    return result[::-1]


def _wavelet_reconstruct(coeffs: List[torch.Tensor], shape: torch.Size) -> torch.Tensor:
    x = coeffs[0].float()
    for detail in coeffs[1:]:
        n = min(x.numel(), detail.numel()); x = x[:n]; d = detail[:n]
        merged = torch.empty(n * 2, device=x.device)
        merged[0::2] = (x + d) * 0.7071
        merged[1::2] = (x - d) * 0.7071
        x = merged
    total = 1
    for s in shape: total *= s
    if x.numel() >= total: return x[:total].reshape(shape)
    return F.pad(x, (0, total - x.numel())).reshape(shape)


class GradientHarmonics:
    """
    GradientHarmonics™ — Wavelet tabanlı gradient işleme motoru.

    1. Harmonik gürültü enjeksiyonu → genelleme arttırır
    2. Wavelet sıkıştırma → dağıtık eğitimde iletim küçülür
    3. Her parametre için ayrı hook — tam kontrol
    """
    def __init__(self, cfg):
        self.cfg   = cfg
        self._step = 0
        self._training = True
        self._stats = dict(injected=0, compressed=0, total=0)
        parts = []
        if cfg.harmonic_noise > 0:    parts.append(f"gürültü={cfg.harmonic_noise:.4f}")
        if cfg.harmonic_compress > 0: parts.append(f"sıkıştırma={cfg.harmonic_compress:.0%}")
        log.info(f"GradHarmonics: 🌊  levels={cfg.harmonic_levels}" +
                 (f", {', '.join(parts)}" if parts else ""))

    def process(self, grad: torch.Tensor, param_name: str = "") -> torch.Tensor:
        self._stats["total"] += 1
        try:
            return self._apply(grad, param_name)
        except Exception as e:
            NexusError.report("HARMONIC_ERR", f"GradHarmonics: {param_name}",
                              str(e), "Ham gradient kullanılıyor", exc=e)
            return grad

    def _apply(self, grad: torch.Tensor, name: str) -> torch.Tensor:
        if grad.numel() < 8: return grad
        cfg = self.cfg; orig_shape = grad.shape
        coeffs = _wavelet_decompose(grad, cfg.harmonic_levels)

        if cfg.harmonic_noise > 0 and cfg.power > 0 and self._training:
            noise_scale = cfg.harmonic_noise * cfg.power
            for i in range(max(0, len(coeffs) - max(1, len(coeffs)//3)), len(coeffs)):
                c   = coeffs[i]
                std = c.float().std().item() + 1e-12
                coeffs[i] = (c.float() + torch.randn_like(c.float()) * std * noise_scale).to(c.dtype)
            self._stats["injected"] += 1

        if cfg.harmonic_compress > 0 and cfg.power > 0:
            ratio = cfg.harmonic_compress * cfg.power
            for i, c in enumerate(coeffs):
                if c.numel() == 0: continue
                threshold = c.float().abs().quantile(ratio)
                coeffs[i] = c * (c.float().abs() >= threshold).to(c.dtype)
            self._stats["compressed"] += 1

        return _wavelet_reconstruct(coeffs, orig_shape).to(grad.dtype)

    def register_hooks(self, model: nn.Module) -> List:
        hooks = []; gh = self
        for name, param in model.named_parameters():
            if param.requires_grad:
                def make_hook(pname):
                    def _hook(grad): return gh.process(grad, pname)
                    return _hook
                hooks.append(param.register_hook(make_hook(name)))
        log.info(f"GradHarmonics: 🌊  {len(hooks)} parametreye hook eklendi")
        return hooks

    def step(self): self._step += 1

    def report(self):
        t = self._stats["total"]
        log.info(f"GradHarmonics: 🌊  {t} gradient — "
                 f"{self._stats['injected']} gürültü, {self._stats['compressed']} sıkıştırma")



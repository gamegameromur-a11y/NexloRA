# NexLoRA Engine - Next-Gen LLM Fine-Tuning

from nexlora.fastlora.fastlora import (
    NexLoRA,
    NexLoRAConfig,
    DeviceManager,
    check_environment,
    # Aliases
    FastLoRA,
    FastLoRAConfig,
)

__version__ = "5.0.0"
__author__ = "NexLoRA Team"
__license__ = "MIT"

__all__ = [
    "NexLoRA",
    "NexLoRAConfig", 
    "DeviceManager",
    "check_environment",
    # Aliases for compatibility
    "FastLoRA",
    "FastLoRAConfig",
]
